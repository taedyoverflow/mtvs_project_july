package com.hunseong.lolcruit.constants;

/**
 * Created by Hunseong on 2022/05/29
 */
public class EmailValidationResult {
    public static final int OK = 0;
    public static final int IS_EXIST_SNS = 1;
    public static final int IS_EXIST_EMAIL = 2;
}

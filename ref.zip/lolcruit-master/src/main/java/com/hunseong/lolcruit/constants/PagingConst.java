package com.hunseong.lolcruit.constants;

/**
 * Created by Hunseong on 2022/05/19
 */
public abstract class PagingConst {
    public static final int BLOCK_PAGE_COUNT = 5;
}

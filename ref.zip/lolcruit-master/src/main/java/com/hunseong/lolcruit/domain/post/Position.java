package com.hunseong.lolcruit.domain.post;

/**
 * Created by Hunseong on 2022/05/18
 */
public enum Position {
    TOP, JUG, MID, ADC, SUP
}

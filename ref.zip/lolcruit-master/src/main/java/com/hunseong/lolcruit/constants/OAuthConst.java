package com.hunseong.lolcruit.constants;

/**
 * Created by Hunseong on 2022/05/28
 */
public class OAuthConst {
    public static final String PASSWORD_SECRET = "lolcruit_secret_1032";
}
